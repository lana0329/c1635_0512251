/*
 * Copyright 2019 Jonathan Chang, Chun-yien <ccy@musicapoetica.org>.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package art.cctcc.c1635.antsomg.demo.y;

import static art.cctcc.c1635.antsomg.demo.y.Vertex_Y.Y.*;
import tech.metacontext.ocnhfa.antsomg.impl.StandardGraph;

/**
 *
 * @author Jonathan Chang, Chun-yien <ccy@musicapoetica.org>
 */
public class Graph_Y extends StandardGraph<Edge_Y, Vertex_Y> {

    public Graph_Y(double alpha, double beta) {

        super(alpha, beta);
        setFraction_mode(StandardGraph.FractionMode.Power);
    }

    @Override
    public void init_graph() {

        var first = Vertex_Y.get(FIRST);
        var last = Vertex_Y.get(LAST);
        var min = Vertex_Y.get(MIN);
        var max = Vertex_Y.get(MAX);
        var ran = Vertex_Y.get(RANDOM);
        var close = Vertex_Y.get(CLOSE);
        
        Vertex_Y[] temp={first,last,min,max,ran,close};
        this.setStart(temp[(int)(Math.random()*6)]);
        var first_first = new Edge_Y(first,first,1.0);
        var first_last = new Edge_Y(first,last,1.0);
        var first_min = new Edge_Y(first,min,1.0);
        var first_max = new Edge_Y(first,max,1.0);
        var first_ran = new Edge_Y(first,ran,1.0);
        var first_close = new Edge_Y(first,close,1.0);
        var last_first = new Edge_Y(last,first,1.0);
        var last_last = new Edge_Y(last,last,1.0);
        var last_min = new Edge_Y(last,min,1.0);
        var last_max = new Edge_Y(last,max,1.0);
        var last_ran = new Edge_Y(last,ran,1.0);
        var last_close = new Edge_Y(last,close,1.0);
        var min_first = new Edge_Y(min,first,1.0);
        var min_last = new Edge_Y(min,last,1.0);
        var min_min = new Edge_Y(min,min,1.0);
        var min_max = new Edge_Y(min,max,1.0);
        var min_ran = new Edge_Y(min,ran,1.0);
        var min_close = new Edge_Y(min,close,1.0);
        var max_first = new Edge_Y(max,first,1.0);
        var max_last = new Edge_Y(max,last,1.0);
        var max_min = new Edge_Y(max,min,1.0);
        var max_max = new Edge_Y(max,max,1.0);
        var max_ran = new Edge_Y(max,ran,1.0);
        var max_close = new Edge_Y(max,close,1.0);
        var ran_first = new Edge_Y(ran,first,1.0);
        var ran_last = new Edge_Y(ran,last,1.0);
        var ran_min = new Edge_Y(ran,min,1.0);
        var ran_max = new Edge_Y(ran,max,1.0);
        var ran_ran = new Edge_Y(ran,ran,1.0);
        var ran_close = new Edge_Y(ran,close,1.0);
        var close_first = new Edge_Y(close,first,1.0);
        var close_last = new Edge_Y(close,last,1.0);
        var close_min = new Edge_Y(close,min,1.0);
        var close_max = new Edge_Y(close,max,1.0);
        var close_ran = new Edge_Y(close,ran,1.0);
        var close_close = new Edge_Y(close,close,1.0);

        this.addEdges(
        first_first,first_last,first_min,first_max,first_ran,first_close,
        last_first,last_last,last_min,last_max,last_ran,last_close,
        min_first,min_last,min_min,min_max,min_ran,min_close,
        max_first,max_last,max_min,max_max,max_ran,max_close,
        ran_first,ran_last,ran_min,ran_max,ran_ran,ran_close,
        close_first,close_last,close_min,close_max,close_ran,close_close);
    }

}
