/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package art.cctcc.c1635.antsomg.demo.classpackage;

/**
 *
 * @author jenny
 */
public class HB_onetwR extends HoneyBlock{
    public HB_onetwR(){
    //super();
    this.pointsID = new int[6];
    edges = new PVector[9];
    pointsID[0]=0;
    pointsID[1]=4;
    pointsID[2]=2;
    pointsID[3]=20;
    pointsID[4]=15;
    pointsID[5]=16;
    connect(0,4,0);
    connect(4,2,1);
    connect(2,0,2);
    connect(0,20,3);
    connect(4,15,4);
    connect(2,16,5);
    connect(15,16,6);
    connect(16,20,7);
    connect(20,15,8);
   
  }
  
  @Override
  public int getKeySurface(int next_type){
    switch(next_type){
      case 1:
        return 2;
      case 2:
        return 4;
      case 3:
        return 6;
      case 4:
        return 20;
      case 5:
        return 22;
      case 6:
        return 24;
      default:
        return 0;
    }
  }
    
}
