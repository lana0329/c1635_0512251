/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package art.cctcc.c1635.antsomg.demo.classpackage;

/**
 *
 * @author jenny
 */
public class HB_half extends HoneyBlock{
    public HB_half(){
    //super();
    this.pointsID = new int[21];
    edges = new PVector[21];
    for(int i=0;i<7;i++)pointsID[i]=i;
    for(int i=0;i<6;i++)pointsID[i+7]=i+14;
    for(int i=1;i<4;i++)connect(0,i,i-1);
    connect(1,4,3);
    connect(4,2,4);
    connect(2,5,5);
    connect(5,3,6);
    connect(3,6,7);
    connect(6,1,8);
    connect(1,14,9);
    connect(4,15,10);
    connect(2,16,11);
    connect(5,17,12);
    connect(3,18,13);
    connect(6,19,14);
    for(int i=0;i<5;i++)connect(i+14,i+15,i+15);
    connect(19,14,20);
  }
  
  @Override
  public int getKeySurface(int next_type){
    if(next_type==1)return 1;
    else return 19;
  }
  
  @Override
  public void computeNewPoints(int next_type){
    float angleY=0;
    float angleZ=0;
    if(next_type!=1) {
      angleY=(float)Math.PI*60/180;
      angleZ=(float)Math.PI;
    }
   
    float[][] rotateY={
      {(float)Math.cos(angleY),0,-(float)Math.sin(angleY)},
      {0,1,0},
      {(float)Math.sin(angleY),0,(float)Math.cos(angleY)}
    };
    float[][] rotateZ={
      {(float)Math.cos(angleZ),-(float)Math.sin(angleZ),0},
      {(float)Math.sin(angleZ),(float)Math.cos(angleZ),0},
      {0,0,1}
    };
    
    for(PVector v: temp_points){
      if(v!=null){
        v.matmul(rotateY,v);
        v.matmul(rotateZ,v);
      }
    }
  }
}
