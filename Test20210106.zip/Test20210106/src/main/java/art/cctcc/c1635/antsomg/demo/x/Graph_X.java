/*
 * Copyright 2019 Jonathan Chang, Chun-yien <ccy@musicapoetica.org>.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package art.cctcc.c1635.antsomg.demo.x;

import art.cctcc.c1635.antsomg.demo.x.Vertex_X.*;
import tech.metacontext.ocnhfa.antsomg.impl.StandardGraph;

/**
 *
 * @author Jonathan Chang, Chun-yien <ccy@musicapoetica.org>
 */
public class Graph_X extends StandardGraph<Edge_X, Vertex_X> {

    public Graph_X(double alpha, double beta) {

        super(alpha, beta);
        setFraction_mode(StandardGraph.FractionMode.Power);
    }

    @Override
    public void init_graph() {

//        var stay = Vertex_X.get(X.STAY);
//        var in = Vertex_X.get(X.IN);
//        var out = Vertex_X.get(X.OUT);
        var N1 = Vertex_X.get(X.N1);
        var N2 = Vertex_X.get(X.N2);
        var N3 = Vertex_X.get(X.N3);
        var N4 = Vertex_X.get(X.N4);
        var N5 = Vertex_X.get(X.N5);
        var N6 = Vertex_X.get(X.N6);
        var N7 = Vertex_X.get(X.N7);
        var N8 = Vertex_X.get(X.N8);
        var N9 = Vertex_X.get(X.N9);
        var N10 = Vertex_X.get(X.N10);
        var N11 = Vertex_X.get(X.N11);
        var N12 = Vertex_X.get(X.N12);
        var N13 = Vertex_X.get(X.N13);
        var N14 = Vertex_X.get(X.N14);
        var N15 = Vertex_X.get(X.N15);
        var N16 = Vertex_X.get(X.N16);
        var N17 = Vertex_X.get(X.N17);
        var N18 = Vertex_X.get(X.N18);
        var N19 = Vertex_X.get(X.N19);
        var N20 = Vertex_X.get(X.N20);
        var N21 = Vertex_X.get(X.N21);
        var N22 = Vertex_X.get(X.N22);
        var N23 = Vertex_X.get(X.N23);
        var N24 = Vertex_X.get(X.N24);
        var N25 = Vertex_X.get(X.N25);
        var N26 = Vertex_X.get(X.N26);
        var N27 = Vertex_X.get(X.N27);
        var N28 = Vertex_X.get(X.N28);
        var N29 = Vertex_X.get(X.N29);
        var N30 = Vertex_X.get(X.N30);
        var N31 = Vertex_X.get(X.N31);
        var N32 = Vertex_X.get(X.N32);
        var N33 = Vertex_X.get(X.N33);
        var N34 = Vertex_X.get(X.N34);
        var N35 = Vertex_X.get(X.N35);
        var N36 = Vertex_X.get(X.N36);
        var N37 = Vertex_X.get(X.N37);
        var N38 = Vertex_X.get(X.N38);
        var N39 = Vertex_X.get(X.N39);
        var N40 = Vertex_X.get(X.N40);
        var N41 = Vertex_X.get(X.N41);
        var N42 = Vertex_X.get(X.N42);
        var full = Vertex_X.get(X.full);
        var half = Vertex_X.get(X.half);
        var sixA = Vertex_X.get(X.sixA);
        var sixB = Vertex_X.get(X.sixB);
        var twL = Vertex_X.get(X.twL);
        var twR = Vertex_X.get(X.twR);
    

        this.setStart(full);

var full_N1 = new Edge_X(full,N1,0.01619);
var full_N2 = new Edge_X(full,N2,0.00020);
var full_N3 = new Edge_X(full,N3,0.00184);
var full_N4 = new Edge_X(full,N4,0.19645);
var full_N5 = new Edge_X(full,N5,0.24321);
var full_N6 = new Edge_X(full,N6,0.00007);
var full_N7 = new Edge_X(full,N7,0.00711);
var full_N8 = new Edge_X(full,N8,0.00730);
var full_N9 = new Edge_X(full,N9,0.01279);
var full_N10 = new Edge_X(full,N10,0.06117);
var full_N11 = new Edge_X(full,N11,0.00041);
var full_N12 = new Edge_X(full,N12,0.00085);
var full_N13 = new Edge_X(full,N13,0.00075);
var full_N14 = new Edge_X(full,N14,1.55846);
var full_N15 = new Edge_X(full,N15,0.04882);
var full_N16 = new Edge_X(full,N16,0.01786);
var full_N17 = new Edge_X(full,N17,0.00138);
var full_N18 = new Edge_X(full,N18,0.00106);
var full_N19 = new Edge_X(full,N19,0.58469);
var full_N20 = new Edge_X(full,N20,0.00098);
var full_N21 = new Edge_X(full,N21,0.00055);
var full_N22 = new Edge_X(full,N22,0.01139);
var full_N23 = new Edge_X(full,N23,0.07857);
var full_N24 = new Edge_X(full,N24,0.02611);
var half_N1 = new Edge_X(half,N1,0.01046);
var half_N2 = new Edge_X(half,N2,0.02513);
var half_N3 = new Edge_X(half,N3,0.00619);
var half_N4 = new Edge_X(half,N4,0.00040);
var half_N5 = new Edge_X(half,N5,0.08964);
var half_N6 = new Edge_X(half,N6,0.00026);
var half_N7 = new Edge_X(half,N7,0.00035);
var half_N8 = new Edge_X(half,N8,0.00063);
var half_N9 = new Edge_X(half,N9,0.00536);
var half_N10 = new Edge_X(half,N10,0.00188);
var half_N11 = new Edge_X(half,N11,0.00144);
var half_N12 = new Edge_X(half,N12,0.04348);
var half_N37 = new Edge_X(half,N37,0.00826);
var half_N38 = new Edge_X(half,N38,0.01095);
var half_N39 = new Edge_X(half,N39,0.04181);
var half_N40 = new Edge_X(half,N40,0.00349);
var half_N41 = new Edge_X(half,N41,1.00335);
var half_N42 = new Edge_X(half,N42,0.40351);
var half_N19 = new Edge_X(half,N19,0.00439);
var half_N20 = new Edge_X(half,N20,0.01176);
var half_N21 = new Edge_X(half,N21,0.00049);
var half_N22 = new Edge_X(half,N22,0.00080);
var half_N23 = new Edge_X(half,N23,0.02216);
var half_N24 = new Edge_X(half,N24,0.02416);
var half_N13 = new Edge_X(half,N13,0.01593);
var half_N14 = new Edge_X(half,N14,0.00518);
var half_N15 = new Edge_X(half,N15,0.00605);
var half_N16 = new Edge_X(half,N16,0.00321);
var half_N17 = new Edge_X(half,N17,0.74206);
var half_N18 = new Edge_X(half,N18,0.00957);
var sixA_N1 = new Edge_X(sixA,N1,0.10089);
var sixA_N2 = new Edge_X(sixA,N2,0.00661);
var sixA_N7 = new Edge_X(sixA,N7,0.28132);
var sixA_N8 = new Edge_X(sixA,N8,0.12199);
var sixA_N25 = new Edge_X(sixA,N25,0.00206);
var sixA_N27 = new Edge_X(sixA,N27,0.00581);
var sixA_N37 = new Edge_X(sixA,N37,0.16228);
var sixA_N38 = new Edge_X(sixA,N38,0.00203);
var sixA_N3 = new Edge_X(sixA,N3,0.00238);
var sixA_N4 = new Edge_X(sixA,N4,0.00052);
var sixA_N9 = new Edge_X(sixA,N9,0.00705);
var sixA_N10 = new Edge_X(sixA,N10,0.08263);
var sixA_N29 = new Edge_X(sixA,N29,0.09208);
var sixA_N39 = new Edge_X(sixA,N39,0.02026);
var sixA_N40 = new Edge_X(sixA,N40,0.00453);
var sixA_N5 = new Edge_X(sixA,N5,0.01592);
var sixA_N6 = new Edge_X(sixA,N6,0.01417);
var sixA_N11 = new Edge_X(sixA,N11,0.10395);
var sixA_N12 = new Edge_X(sixA,N12,0.00828);
var sixA_N41 = new Edge_X(sixA,N41,0.00119);
var sixA_N42 = new Edge_X(sixA,N42,0.05165);
var sixA_N19 = new Edge_X(sixA,N19,0.02450);
var sixA_N24 = new Edge_X(sixA,N24,0.00214);
var sixA_N13 = new Edge_X(sixA,N13,0.10463);
var sixA_N18 = new Edge_X(sixA,N18,0.38573);
var sixA_N32 = new Edge_X(sixA,N32,0.00174);
var sixA_N36 = new Edge_X(sixA,N36,0.00194);
var sixA_N20 = new Edge_X(sixA,N20,0.00068);
var sixA_N21 = new Edge_X(sixA,N21,0.67487);
var sixA_N14 = new Edge_X(sixA,N14,12.95982);
var sixA_N15 = new Edge_X(sixA,N15,0.13681);
var sixA_N34 = new Edge_X(sixA,N34,0.05249);
var sixA_N22 = new Edge_X(sixA,N22,0.05896);
var sixA_N23 = new Edge_X(sixA,N23,0.00113);
var sixA_N16 = new Edge_X(sixA,N16,0.00121);
var sixA_N17 = new Edge_X(sixA,N17,31.53284);
var sixB_N6 = new Edge_X(sixB,N6,0.60907);
var sixB_N1 = new Edge_X(sixB,N1,0.00267);
var sixB_N12 = new Edge_X(sixB,N12,0.03667);
var sixB_N7 = new Edge_X(sixB,N7,0.00428);
var sixB_N30 = new Edge_X(sixB,N30,0.00752);
var sixB_N26 = new Edge_X(sixB,N26,0.00079);
var sixB_N42 = new Edge_X(sixB,N42,5.71520);
var sixB_N37 = new Edge_X(sixB,N37,0.11853);
var sixB_N2 = new Edge_X(sixB,N2,0.03296);
var sixB_N3 = new Edge_X(sixB,N3,0.00321);
var sixB_N8 = new Edge_X(sixB,N8,0.01941);
var sixB_N9 = new Edge_X(sixB,N9,0.62518);
var sixB_N28 = new Edge_X(sixB,N28,0.01978);
var sixB_N38 = new Edge_X(sixB,N38,0.05637);
var sixB_N39 = new Edge_X(sixB,N39,0.01431);
var sixB_N4 = new Edge_X(sixB,N4,0.00251);
var sixB_N5 = new Edge_X(sixB,N5,0.02576);
var sixB_N10 = new Edge_X(sixB,N10,0.05607);
var sixB_N11 = new Edge_X(sixB,N11,0.00226);
var sixB_N40 = new Edge_X(sixB,N40,0.03052);
var sixB_N41 = new Edge_X(sixB,N41,0.00511);
var sixB_N19 = new Edge_X(sixB,N19,0.00263);
var sixB_N20 = new Edge_X(sixB,N20,0.00806);
var sixB_N13 = new Edge_X(sixB,N13,0.56330);
var sixB_N14 = new Edge_X(sixB,N14,0.03567);
var sixB_N31 = new Edge_X(sixB,N31,0.00059);
var sixB_N33 = new Edge_X(sixB,N33,0.00367);
var sixB_N21 = new Edge_X(sixB,N21,0.35699);
var sixB_N22 = new Edge_X(sixB,N22,0.12498);
var sixB_N15 = new Edge_X(sixB,N15,0.01517);
var sixB_N16 = new Edge_X(sixB,N16,0.00261);
var sixB_N35 = new Edge_X(sixB,N35,0.23292);
var sixB_N23 = new Edge_X(sixB,N23,0.07648);
var sixB_N24 = new Edge_X(sixB,N24,1.16021);
var sixB_N17 = new Edge_X(sixB,N17,0.00551);
var sixB_N18 = new Edge_X(sixB,N18,0.00212);
var twL_N1 = new Edge_X(twL,N1,0.01157);
var twL_N25 = new Edge_X(twL,N25,0.00623);
var twL_N7 = new Edge_X(twL,N7,0.00336);
var twL_N26 = new Edge_X(twL,N26,0.00064);
var twL_N37 = new Edge_X(twL,N37,0.00307);
var twL_N3 = new Edge_X(twL,N3,0.01394);
var twL_N27 = new Edge_X(twL,N27,0.00969);
var twL_N9 = new Edge_X(twL,N9,0.00976);
var twL_N28 = new Edge_X(twL,N28,0.00128);
var twL_N39 = new Edge_X(twL,N39,0.02060);
var twL_N5 = new Edge_X(twL,N5,0.01569);
var twL_N29 = new Edge_X(twL,N29,0.00036);
var twL_N11 = new Edge_X(twL,N11,0.00343);
var twL_N30 = new Edge_X(twL,N30,0.00192);
var twL_N41 = new Edge_X(twL,N41,0.03450);
var twL_N19 = new Edge_X(twL,N19,0.03278);
var twL_N31 = new Edge_X(twL,N31,1.15612);
var twL_N13 = new Edge_X(twL,N13,0.00738);
var twL_N32 = new Edge_X(twL,N32,0.01262);
var twL_N21 = new Edge_X(twL,N21,0.00813);
var twL_N33 = new Edge_X(twL,N33,0.00181);
var twL_N15 = new Edge_X(twL,N15,0.00312);
var twL_N34 = new Edge_X(twL,N34,0.01025);
var twL_N23 = new Edge_X(twL,N23,0.00225);
var twL_N35 = new Edge_X(twL,N35,0.00031);
var twL_N17 = new Edge_X(twL,N17,0.01529);
var twL_N36 = new Edge_X(twL,N36,0.00047);
var twR_N2 = new Edge_X(twR,N2,0.00204);
var twR_N26 = new Edge_X(twR,N26,0.02552);
var twR_N8 = new Edge_X(twR,N8,0.00038);
var twR_N27 = new Edge_X(twR,N27,0.00015);
var twR_N38 = new Edge_X(twR,N38,0.08266);
var twR_N4 = new Edge_X(twR,N4,1.36580);
var twR_N28 = new Edge_X(twR,N28,1.52707);
var twR_N10 = new Edge_X(twR,N10,0.00854);
var twR_N29 = new Edge_X(twR,N29,0.00108);
var twR_N40 = new Edge_X(twR,N40,0.01273);
var twR_N6 = new Edge_X(twR,N6,0.00043);
var twR_N30 = new Edge_X(twR,N30,0.00043);
var twR_N12 = new Edge_X(twR,N12,0.16266);
var twR_N25 = new Edge_X(twR,N25,0.03800);
var twR_N42 = new Edge_X(twR,N42,0.14294);
var twR_N20 = new Edge_X(twR,N20,0.02926);
var twR_N32 = new Edge_X(twR,N32,0.00301);
var twR_N14 = new Edge_X(twR,N14,3.68961);
var twR_N33 = new Edge_X(twR,N33,0.00254);
var twR_N22 = new Edge_X(twR,N22,0.00634);
var twR_N34 = new Edge_X(twR,N34,0.13444);
var twR_N24 = new Edge_X(twR,N24,0.00845);
var twR_N36 = new Edge_X(twR,N36,0.00018);
var twR_N18 = new Edge_X(twR,N18,0.27205);
var twR_N31 = new Edge_X(twR,N31,0.00020);
var N1_full = new Edge_X(N1,full,2.45003);
var N1_half = new Edge_X(N1,half,0.19893);
var N1_sixA = new Edge_X(N1,sixA,0.00434);
var N1_sixB = new Edge_X(N1,sixB,0.01926);
var N1_twL = new Edge_X(N1,twL,0.00746);
var N1_twR = new Edge_X(N1,twR,0.00433);
var N2_full = new Edge_X(N2,full,0.01822);
var N2_half = new Edge_X(N2,half,0.00343);
var N2_sixA = new Edge_X(N2,sixA,0.00048);
var N2_sixB = new Edge_X(N2,sixB,0.00091);
var N2_twL = new Edge_X(N2,twL,0.04252);
var N2_twR = new Edge_X(N2,twR,0.00432);
var N3_full = new Edge_X(N3,full,0.00222);
var N3_half = new Edge_X(N3,half,0.00990);
var N3_sixA = new Edge_X(N3,sixA,0.08067);
var N3_sixB = new Edge_X(N3,sixB,0.02102);
var N3_twL = new Edge_X(N3,twL,0.00055);
var N3_twR = new Edge_X(N3,twR,0.13621);
var N4_full = new Edge_X(N4,full,0.00161);
var N4_half = new Edge_X(N4,half,0.00127);
var N4_sixA = new Edge_X(N4,sixA,0.00191);
var N4_sixB = new Edge_X(N4,sixB,0.00163);
var N4_twL = new Edge_X(N4,twL,0.00273);
var N4_twR = new Edge_X(N4,twR,0.08308);
var N5_full = new Edge_X(N5,full,0.00385);
var N5_half = new Edge_X(N5,half,0.63994);
var N5_sixA = new Edge_X(N5,sixA,0.01972);
var N5_sixB = new Edge_X(N5,sixB,0.39238);
var N5_twL = new Edge_X(N5,twL,0.18909);
var N5_twR = new Edge_X(N5,twR,2.97169);
var N6_full = new Edge_X(N6,full,0.05910);
var N6_half = new Edge_X(N6,half,0.00012);
var N6_sixA = new Edge_X(N6,sixA,0.00659);
var N6_sixB = new Edge_X(N6,sixB,0.00151);
var N6_twL = new Edge_X(N6,twL,0.00046);
var N6_twR = new Edge_X(N6,twR,0.00022);
var N7_full = new Edge_X(N7,full,0.00059);
var N7_half = new Edge_X(N7,half,0.00090);
var N7_sixA = new Edge_X(N7,sixA,0.01158);
var N7_sixB = new Edge_X(N7,sixB,0.07458);
var N7_twL = new Edge_X(N7,twL,0.00375);
var N7_twR = new Edge_X(N7,twR,0.87447);
var N8_full = new Edge_X(N8,full,0.01149);
var N8_half = new Edge_X(N8,half,13.08374);
var N8_sixA = new Edge_X(N8,sixA,0.01267);
var N8_sixB = new Edge_X(N8,sixB,0.47867);
var N8_twL = new Edge_X(N8,twL,0.00030);
var N8_twR = new Edge_X(N8,twR,0.00060);
var N9_full = new Edge_X(N9,full,0.02304);
var N9_half = new Edge_X(N9,half,0.00282);
var N9_sixA = new Edge_X(N9,sixA,1.02400);
var N9_sixB = new Edge_X(N9,sixB,0.00777);
var N9_twL = new Edge_X(N9,twL,0.04448);
var N9_twR = new Edge_X(N9,twR,0.03053);
var N10_full = new Edge_X(N10,full,0.03784);
var N10_half = new Edge_X(N10,half,0.00292);
var N10_sixA = new Edge_X(N10,sixA,0.02943);
var N10_sixB = new Edge_X(N10,sixB,0.13272);
var N10_twL = new Edge_X(N10,twL,0.01073);
var N10_twR = new Edge_X(N10,twR,0.02665);
var N11_full = new Edge_X(N11,full,0.26145);
var N11_half = new Edge_X(N11,half,6.29699);
var N11_sixA = new Edge_X(N11,sixA,0.00070);
var N11_sixB = new Edge_X(N11,sixB,0.00547);
var N11_twL = new Edge_X(N11,twL,0.01405);
var N11_twR = new Edge_X(N11,twR,0.00027);
var N12_full = new Edge_X(N12,full,0.66048);
var N12_half = new Edge_X(N12,half,0.22494);
var N12_sixA = new Edge_X(N12,sixA,0.13423);
var N12_sixB = new Edge_X(N12,sixB,0.00252);
var N12_twL = new Edge_X(N12,twL,0.00162);
var N12_twR = new Edge_X(N12,twR,0.00988);
var N13_full = new Edge_X(N13,full,0.00585);
var N13_half = new Edge_X(N13,half,0.06639);
var N13_sixA = new Edge_X(N13,sixA,0.09888);
var N13_sixB = new Edge_X(N13,sixB,0.02334);
var N13_twL = new Edge_X(N13,twL,0.00622);
var N13_twR = new Edge_X(N13,twR,0.00168);
var N14_full = new Edge_X(N14,full,0.01064);
var N14_half = new Edge_X(N14,half,0.73363);
var N14_sixA = new Edge_X(N14,sixA,6.62232);
var N14_sixB = new Edge_X(N14,sixB,0.07502);
var N14_twL = new Edge_X(N14,twL,0.14089);
var N14_twR = new Edge_X(N14,twR,0.05350);
var N15_full = new Edge_X(N15,full,0.01426);
var N15_half = new Edge_X(N15,half,0.00764);
var N15_sixA = new Edge_X(N15,sixA,0.05252);
var N15_sixB = new Edge_X(N15,sixB,0.00708);
var N15_twL = new Edge_X(N15,twL,0.03748);
var N15_twR = new Edge_X(N15,twR,0.01877);
var N16_full = new Edge_X(N16,full,0.02314);
var N16_half = new Edge_X(N16,half,0.00077);
var N16_sixA = new Edge_X(N16,sixA,0.00496);
var N16_sixB = new Edge_X(N16,sixB,0.10495);
var N16_twL = new Edge_X(N16,twL,0.01456);
var N16_twR = new Edge_X(N16,twR,0.01226);
var N17_full = new Edge_X(N17,full,0.00963);
var N17_half = new Edge_X(N17,half,0.00993);
var N17_sixA = new Edge_X(N17,sixA,0.06223);
var N17_sixB = new Edge_X(N17,sixB,0.00221);
var N17_twL = new Edge_X(N17,twL,0.29537);
var N17_twR = new Edge_X(N17,twR,0.03900);
var N18_full = new Edge_X(N18,full,4.52375);
var N18_half = new Edge_X(N18,half,0.00091);
var N18_sixA = new Edge_X(N18,sixA,0.11876);
var N18_sixB = new Edge_X(N18,sixB,0.00130);
var N18_twL = new Edge_X(N18,twL,3.38241);
var N18_twR = new Edge_X(N18,twR,0.04230);
var N19_full = new Edge_X(N19,full,0.00362);
var N19_half = new Edge_X(N19,half,0.05433);
var N19_sixA = new Edge_X(N19,sixA,0.12573);
var N19_sixB = new Edge_X(N19,sixB,0.00434);
var N19_twL = new Edge_X(N19,twL,0.03334);
var N19_twR = new Edge_X(N19,twR,0.02851);
var N20_full = new Edge_X(N20,full,0.00138);
var N20_half = new Edge_X(N20,half,0.16269);
var N20_sixA = new Edge_X(N20,sixA,0.00153);
var N20_sixB = new Edge_X(N20,sixB,0.16084);
var N20_twL = new Edge_X(N20,twL,0.00471);
var N20_twR = new Edge_X(N20,twR,0.00114);
var N21_full = new Edge_X(N21,full,0.00170);
var N21_half = new Edge_X(N21,half,0.13293);
var N21_sixA = new Edge_X(N21,sixA,9.26934);
var N21_sixB = new Edge_X(N21,sixB,0.00144);
var N21_twL = new Edge_X(N21,twL,0.00136);
var N21_twR = new Edge_X(N21,twR,0.00143);
var N22_full = new Edge_X(N22,full,0.00109);
var N22_half = new Edge_X(N22,half,0.01110);
var N22_sixA = new Edge_X(N22,sixA,0.01381);
var N22_sixB = new Edge_X(N22,sixB,0.02337);
var N22_twL = new Edge_X(N22,twL,0.02362);
var N22_twR = new Edge_X(N22,twR,0.02530);
var N23_full = new Edge_X(N23,full,0.10218);
var N23_half = new Edge_X(N23,half,0.00567);
var N23_sixA = new Edge_X(N23,sixA,0.00589);
var N23_sixB = new Edge_X(N23,sixB,0.00973);
var N23_twL = new Edge_X(N23,twL,0.00824);
var N23_twR = new Edge_X(N23,twR,0.00326);
var N24_full = new Edge_X(N24,full,0.09635);
var N24_half = new Edge_X(N24,half,3.42426);
var N24_sixA = new Edge_X(N24,sixA,0.02396);
var N24_sixB = new Edge_X(N24,sixB,0.05490);
var N24_twL = new Edge_X(N24,twL,0.01676);
var N24_twR = new Edge_X(N24,twR,0.00145);
var N25_full = new Edge_X(N25,full,0.00627);
var N25_half = new Edge_X(N25,half,0.72910);
var N25_sixA = new Edge_X(N25,sixA,0.74917);
var N25_sixB = new Edge_X(N25,sixB,0.03070);
var N25_twL = new Edge_X(N25,twL,0.00689);
var N25_twR = new Edge_X(N25,twR,0.01186);
var N26_full = new Edge_X(N26,full,0.00090);
var N26_half = new Edge_X(N26,half,0.01524);
var N26_sixA = new Edge_X(N26,sixA,0.00208);
var N26_sixB = new Edge_X(N26,sixB,0.00698);
var N26_twL = new Edge_X(N26,twL,0.00965);
var N26_twR = new Edge_X(N26,twR,9.43357);
var N27_full = new Edge_X(N27,full,0.05143);
var N27_half = new Edge_X(N27,half,0.00604);
var N27_sixA = new Edge_X(N27,sixA,0.00076);
var N27_sixB = new Edge_X(N27,sixB,0.16277);
var N27_twL = new Edge_X(N27,twL,0.00206);
var N27_twR = new Edge_X(N27,twR,0.00091);
var N28_full = new Edge_X(N28,full,0.97883);
var N28_half = new Edge_X(N28,half,0.31723);
var N28_sixA = new Edge_X(N28,sixA,0.01860);
var N28_sixB = new Edge_X(N28,sixB,0.00651);
var N28_twL = new Edge_X(N28,twL,0.01565);
var N28_twR = new Edge_X(N28,twR,0.01876);
var N29_full = new Edge_X(N29,full,0.00096);
var N29_half = new Edge_X(N29,half,0.00192);
var N29_sixA = new Edge_X(N29,sixA,27.55737);
var N29_sixB = new Edge_X(N29,sixB,0.01418);
var N29_twL = new Edge_X(N29,twL,0.75636);
var N29_twR = new Edge_X(N29,twR,0.00151);
var N30_full = new Edge_X(N30,full,0.13837);
var N30_half = new Edge_X(N30,half,0.00106);
var N30_sixA = new Edge_X(N30,sixA,0.00124);
var N30_sixB = new Edge_X(N30,sixB,0.00515);
var N30_twL = new Edge_X(N30,twL,0.04732);
var N30_twR = new Edge_X(N30,twR,0.02267);
var N31_full = new Edge_X(N31,full,0.00072);
var N31_half = new Edge_X(N31,half,0.00051);
var N31_sixA = new Edge_X(N31,sixA,0.08921);
var N31_sixB = new Edge_X(N31,sixB,0.11027);
var N31_twL = new Edge_X(N31,twL,0.03459);
var N31_twR = new Edge_X(N31,twR,0.00157);
var N32_full = new Edge_X(N32,full,0.00554);
var N32_half = new Edge_X(N32,half,0.03322);
var N32_sixA = new Edge_X(N32,sixA,0.00373);
var N32_sixB = new Edge_X(N32,sixB,0.02258);
var N32_twL = new Edge_X(N32,twL,0.01234);
var N32_twR = new Edge_X(N32,twR,0.12250);
var N33_full = new Edge_X(N33,full,0.03068);
var N33_half = new Edge_X(N33,half,0.01992);
var N33_sixA = new Edge_X(N33,sixA,0.00303);
var N33_sixB = new Edge_X(N33,sixB,0.00598);
var N33_twL = new Edge_X(N33,twL,0.00460);
var N33_twR = new Edge_X(N33,twR,0.05172);
var N34_full = new Edge_X(N34,full,1.00440);
var N34_half = new Edge_X(N34,half,0.03386);
var N34_sixA = new Edge_X(N34,sixA,0.16144);
var N34_sixB = new Edge_X(N34,sixB,0.16956);
var N34_twL = new Edge_X(N34,twL,0.05114);
var N34_twR = new Edge_X(N34,twR,0.22837);
var N35_full = new Edge_X(N35,full,0.00397);
var N35_half = new Edge_X(N35,half,0.23695);
var N35_sixA = new Edge_X(N35,sixA,0.01893);
var N35_sixB = new Edge_X(N35,sixB,0.01686);
var N35_twL = new Edge_X(N35,twL,0.00234);
var N35_twR = new Edge_X(N35,twR,0.01463);
var N36_full = new Edge_X(N36,full,0.00019);
var N36_half = new Edge_X(N36,half,0.02634);
var N36_sixA = new Edge_X(N36,sixA,0.00087);
var N36_sixB = new Edge_X(N36,sixB,0.03775);
var N36_twL = new Edge_X(N36,twL,0.00718);
var N36_twR = new Edge_X(N36,twR,0.00183);
var N37_full = new Edge_X(N37,full,0.00755);
var N37_half = new Edge_X(N37,half,0.05888);
var N37_sixA = new Edge_X(N37,sixA,0.12454);
var N37_sixB = new Edge_X(N37,sixB,0.40104);
var N37_twL = new Edge_X(N37,twL,0.01303);
var N37_twR = new Edge_X(N37,twR,0.01805);
var N38_full = new Edge_X(N38,full,0.03534);
var N38_half = new Edge_X(N38,half,0.27754);
var N38_sixA = new Edge_X(N38,sixA,0.00267);
var N38_sixB = new Edge_X(N38,sixB,0.23366);
var N38_twL = new Edge_X(N38,twL,0.01211);
var N38_twR = new Edge_X(N38,twR,0.06951);
var N39_full = new Edge_X(N39,full,0.01206);
var N39_half = new Edge_X(N39,half,0.35725);
var N39_sixA = new Edge_X(N39,sixA,1.65109);
var N39_sixB = new Edge_X(N39,sixB,0.03732);
var N39_twL = new Edge_X(N39,twL,0.04252);
var N39_twR = new Edge_X(N39,twR,0.01988);
var N40_full = new Edge_X(N40,full,0.50617);
var N40_half = new Edge_X(N40,half,0.00165);
var N40_sixA = new Edge_X(N40,sixA,0.28331);
var N40_sixB = new Edge_X(N40,sixB,0.01719);
var N40_twL = new Edge_X(N40,twL,0.00761);
var N40_twR = new Edge_X(N40,twR,0.29350);
var N41_full = new Edge_X(N41,full,0.00257);
var N41_half = new Edge_X(N41,half,0.00206);
var N41_sixA = new Edge_X(N41,sixA,0.24914);
var N41_sixB = new Edge_X(N41,sixB,0.31665);
var N41_twL = new Edge_X(N41,twL,4.71034);
var N41_twR = new Edge_X(N41,twR,0.02858);
var N42_full = new Edge_X(N42,full,1.49061);
var N42_half = new Edge_X(N42,half,0.06300);
var N42_sixA = new Edge_X(N42,sixA,1.92736);
var N42_sixB = new Edge_X(N42,sixB,0.24369);
var N42_twL = new Edge_X(N42,twL,0.42629);
var N42_twR = new Edge_X(N42,twR,5.34397);

        this.addEdges(
        full_N1,full_N2,full_N3,full_N4,full_N5,full_N6,
        full_N7,full_N8,full_N9,full_N10,full_N11,
        full_N12,full_N13,full_N14,full_N15,full_N16,
        full_N17,full_N18,full_N19,full_N20,full_N21,
        full_N22,full_N23,full_N24,half_N1,half_N2,half_N3,
        half_N4,half_N5,half_N6,half_N7,half_N8,half_N9,
        half_N10,half_N11,half_N12,half_N37,half_N38,
        half_N39,half_N40,half_N41,half_N42,half_N19,
        half_N20,half_N21,half_N22,half_N23,half_N24,
        half_N13,half_N14,half_N15,half_N16,half_N17,
        half_N18,sixA_N1,sixA_N2,sixA_N7,sixA_N8,
        sixA_N25,sixA_N27,sixA_N37,sixA_N38,sixA_N3,
        sixA_N4,sixA_N9,sixA_N10,sixA_N29,sixA_N39,
        sixA_N40,sixA_N5,sixA_N6,sixA_N11,sixA_N12,
        sixA_N41,sixA_N42,sixA_N19,sixA_N24,sixA_N13,
        sixA_N18,sixA_N32,sixA_N36,sixA_N20,sixA_N21,
        sixA_N14,sixA_N15,sixA_N34,sixA_N22,sixA_N23,
        sixA_N16,sixA_N17,sixB_N6,sixB_N1,sixB_N12,
        sixB_N7,sixB_N30,sixB_N26,sixB_N42,sixB_N37,
        sixB_N2,sixB_N3,sixB_N8,sixB_N9,sixB_N28,
        sixB_N38,sixB_N39,sixB_N4,sixB_N5,sixB_N10,
        sixB_N11,sixB_N40,sixB_N41,sixB_N19,sixB_N20,
        sixB_N13,sixB_N14,sixB_N31,sixB_N33,sixB_N21,
        sixB_N22,sixB_N15,sixB_N16,sixB_N35,sixB_N23,
        sixB_N24,sixB_N17,sixB_N18,twL_N1,twL_N25,
        twL_N7,twL_N26,twL_N37,twL_N3,twL_N27,
        twL_N9,twL_N28,twL_N39,twL_N5,twL_N29,
        twL_N11,twL_N30,twL_N41,twL_N19,twL_N31,
        twL_N13,twL_N32,twL_N21,twL_N33,twL_N15,
        twL_N34,twL_N23,twL_N35,twL_N17,twL_N36,
        twR_N2,twR_N26,twR_N8,twR_N27,twR_N38,
        twR_N4,twR_N28,twR_N10,twR_N29,twR_N40,
        twR_N6,twR_N30,twR_N12,twR_N25,twR_N42,
        twR_N20,twR_N32,twR_N14,twR_N33,twR_N22,
        twR_N34,twR_N24,twR_N36,twR_N18,twR_N31,
        N1_full,N1_half,N1_sixA,N1_sixB,N1_twL,N1_twR,
        N2_full,N2_half,N2_sixA,N2_sixB,N2_twL,N2_twR,
        N3_full,N3_half,N3_sixA,N3_sixB,N3_twL,N3_twR,
        N4_full,N4_half,N4_sixA,N4_sixB,N4_twL,N4_twR,
        N5_full,N5_half,N5_sixA,N5_sixB,N5_twL,N5_twR,
        N6_full,N6_half,N6_sixA,N6_sixB,N6_twL,N6_twR,
        N7_full,N7_half,N7_sixA,N7_sixB,N7_twL,N7_twR,
        N8_full,N8_half,N8_sixA,N8_sixB,N8_twL,N8_twR,
        N9_full,N9_half,N9_sixA,N9_sixB,N9_twL,N9_twR,
        N10_full,N10_half,N10_sixA,N10_sixB,N10_twL,N10_twR,
        N11_full,N11_half,N11_sixA,N11_sixB,N11_twL,N11_twR,
        N12_full,N12_half,N12_sixA,N12_sixB,N12_twL,N12_twR,
        N13_full,N13_half,N13_sixA,N13_sixB,N13_twL,N13_twR,
        N14_full,N14_half,N14_sixA,N14_sixB,N14_twL,N14_twR,
        N15_full,N15_half,N15_sixA,N15_sixB,N15_twL,N15_twR,
        N16_full,N16_half,N16_sixA,N16_sixB,N16_twL,N16_twR,
        N17_full,N17_half,N17_sixA,N17_sixB,N17_twL,N17_twR,
        N18_full,N18_half,N18_sixA,N18_sixB,N18_twL,N18_twR,
        N19_full,N19_half,N19_sixA,N19_sixB,N19_twL,N19_twR,
        N20_full,N20_half,N20_sixA,N20_sixB,N20_twL,N20_twR,
        N21_full,N21_half,N21_sixA,N21_sixB,N21_twL,N21_twR,
        N22_full,N22_half,N22_sixA,N22_sixB,N22_twL,N22_twR,
        N23_full,N23_half,N23_sixA,N23_sixB,N23_twL,N23_twR,
        N24_full,N24_half,N24_sixA,N24_sixB,N24_twL,N24_twR,
        N25_full,N25_half,N25_sixA,N25_sixB,N25_twL,N25_twR,
        N26_full,N26_half,N26_sixA,N26_sixB,N26_twL,N26_twR,
        N27_full,N27_half,N27_sixA,N27_sixB,N27_twL,N27_twR,
        N28_full,N28_half,N28_sixA,N28_sixB,N28_twL,N28_twR,
        N29_full,N29_half,N29_sixA,N29_sixB,N29_twL,N29_twR,
        N30_full,N30_half,N30_sixA,N30_sixB,N30_twL,N30_twR,
        N31_full,N31_half,N31_sixA,N31_sixB,N31_twL,N31_twR,
        N32_full,N32_half,N32_sixA,N32_sixB,N32_twL,N32_twR,
        N33_full,N33_half,N33_sixA,N33_sixB,N33_twL,N33_twR,
        N34_full,N34_half,N34_sixA,N34_sixB,N34_twL,N34_twR,
        N35_full,N35_half,N35_sixA,N35_sixB,N35_twL,N35_twR,
        N36_full,N36_half,N36_sixA,N36_sixB,N36_twL,N36_twR,
        N37_full,N37_half,N37_sixA,N37_sixB,N37_twL,N37_twR,
        N38_full,N38_half,N38_sixA,N38_sixB,N38_twL,N38_twR,
        N39_full,N39_half,N39_sixA,N39_sixB,N39_twL,N39_twR,
        N40_full,N40_half,N40_sixA,N40_sixB,N40_twL,N40_twR,
        N41_full,N41_half,N41_sixA,N41_sixB,N41_twL,N41_twR,
        N42_full,N42_half,N42_sixA,N42_sixB,N42_twL,N42_twR
        );
    }
}
