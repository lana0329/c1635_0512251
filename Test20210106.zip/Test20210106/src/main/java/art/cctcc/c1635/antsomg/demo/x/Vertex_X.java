/*
 * Copyright 2019 Jonathan Chang, Chun-yien <ccy@musicapoetica.org>.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package art.cctcc.c1635.antsomg.demo.x;

import java.util.HashMap;
import java.util.Map;
import tech.metacontext.ocnhfa.antsomg.impl.StandardVertex;

/**
 *
 * @author Jonathan Chang, Chun-yien <ccy@musicapoetica.org>
 */
public class Vertex_X extends StandardVertex {

    private static Map<X, Vertex_X> instances
            = new HashMap<>();

    public static enum X {
        //STAY, OUT, IN;
        N1,N2,N3,N4,N5,N6,N7,N8,N9,N10,N11,N12,
        N13,N14,N15,N16,N17,N18,N19,N20,N21,N22,
        N23,N24,N25,N26,N27,N28,N29,N30,N31,N32,
        N33,N34,N35,N36,N37,N38,N39,N40,N41,N42,
        full,half,sixA,sixB,twL,twR;
        X() {
            instances.put(this, new Vertex_X(this));
        }
    }

    private Vertex_X(X name) {

        super(name.toString());
    }

    public static Vertex_X get(X name) {

        return instances.get(name);
    }
}
