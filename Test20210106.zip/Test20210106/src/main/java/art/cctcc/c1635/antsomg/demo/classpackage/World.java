/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package art.cctcc.c1635.antsomg.demo.classpackage;

import java.util.ArrayList;
/**
 *
 * @author jenny
 */
public class World {
    public ArrayList <Space> spaces;
    public ArrayList <HB_full> hbs_full;
    public ArrayList <HB_half> hbs_half;
    public ArrayList <HB_onesixA> hbs_sixA;
    public ArrayList <HB_onesixB> hbs_sixB;
    public ArrayList <HB_onetwL> hbs_twL;
    public ArrayList <HB_onetwR> hbs_twR;
    public ArrayList <ArrayList<? extends HoneyBlock>> blocksList;
    boolean ifTheFirst;
    public int[][][] srf={
  {
    {1,1,1},
    {1,1,2},
    {1,1,3},
    {1,1,4},
    {1,1,5},
    {1,1,6},
    {1,1,7},
    {1,1,8},
    {1,1,9},
    {1,1,10},
    {1,1,11},
    {1,1,12},
    {1,1,13},
    {1,1,14},
    {1,1,15},
    {1,1,16},
    {1,1,17},
    {1,1,18},
    {1,1,19},
    {1,1,20},
    {1,1,21},
    {1,1,22},
    {1,1,23},
    {1,1,24}
  },
  {
    {2,1,1},
    {2,1,2},
    {2,1,3},
    {2,1,4},
    {2,1,5},
    {2,1,6},
    {2,1,7},
    {2,1,8},
    {2,1,9},
    {2,1,10},
    {2,1,11},
    {2,1,12},
    {2,1,37},
    {2,1,38},
    {2,1,39},
    {2,1,40},
    {2,1,41},
    {2,1,42}
  },
  {
    {2,2,19},
    {2,2,20},
    {2,2,21},
    {2,2,22},
    {2,2,23},
    {2,2,24},
    {2,2,13},
    {2,2,14},
    {2,2,15},
    {2,2,16},
    {2,2,17},
    {2,2,18},
    {2,2,37},
    {2,2,38},
    {2,2,39},
    {2,2,40},
    {2,2,41},
    {2,2,42}
  },
  {
    {3,1,1},
    {3,1,2},
    {3,1,7},
    {3,1,8},
    {3,1,25},
    {3,1,27},
    {3,1,37},
    {3,1,38}
  },
  {
    {3,2,3},
    {3,2,4},
    {3,2,9},
    {3,2,10},
    {3,2,27},
    {3,2,29},
    {3,2,39},
    {3,2,40}
  },
  {
    {3,3,5},
    {3,3,6},
    {3,3,11},
    {3,3,12},
    {3,3,25},
    {3,3,29},
    {3,3,41},
    {3,3,42}
  },
  {
    {3,4,19},
    {3,4,24},
    {3,4,13},
    {3,4,18},
    {3,4,32},
    {3,4,36},
    {3,4,37},
    {3,4,42}
  },
  {
    {3,5,20},
    {3,5,21},
    {3,5,14},
    {3,5,15},
    {3,5,32},
    {3,5,34},
    {3,5,38},
    {3,5,39}
  },
  {
    {3,6,22},
    {3,6,23},
    {3,6,16},
    {3,6,17},
    {3,6,34},
    {3,6,36},
    {3,6,40},
    {3,6,41}
  },
  {
    {4,1,6},
    {4,1,1},
    {4,1,12},
    {4,1,7},
    {4,1,30},
    {4,1,26},
    {4,1,42},
    {4,1,37}
  },
  {
    {4,2,2},
    {4,2,3},
    {4,2,8},
    {4,2,9},
    {4,2,26},
    {4,2,28},
    {4,2,38},
    {4,2,39}
  },
  {
    {4,3,4},
    {4,3,5},
    {4,3,10},
    {4,3,11},
    {4,3,28},
    {4,3,30},
    {4,3,40},
    {4,3,41}
  },
  {
    {4,4,19},
    {4,4,20},
    {4,4,13},
    {4,4,14},
    {4,4,31},
    {4,4,33},
    {4,4,37},
    {4,4,38}
  },
  {
    {4,5,21},
    {4,5,22},
    {4,5,15},
    {4,5,16},
    {4,5,33},
    {4,5,35},
    {4,5,39},
    {4,5,40}
  },
  {
    {4,6,23},
    {4,6,24},
    {4,6,17},
    {4,6,18},
    {4,6,31},
    {4,6,35},
    {4,6,41},
    {4,6,42}
  },
  {
    {5,1,1},
    {5,1,25},
    {5,1,7},
    {5,1,26},
    {5,1,37}
  },
  {
    {5,2,3},
    {5,2,27},
    {5,2,9},
    {5,2,28},
    {5,2,39}
  },
  {
    {5,3,5},
    {5,3,29},
    {5,3,11},
    {5,3,30},
    {5,3,41}
  },
  {
    {5,4,19},
    {5,4,31},
    {5,4,13},
    {5,4,32},
    {5,4,37}
  },
  {
    {5,5,21},
    {5,5,33},
    {5,5,15},
    {5,5,34},
    {5,5,39}
  },
  {
    {5,6,23},
    {5,6,35},
    {5,6,17},
    {5,6,36},
    {5,6,41}
  },
  {
    {6,1,2},
    {6,1,26},
    {6,1,8},
    {6,1,27},
    {6,1,38}
  },
  {
    {6,2,4},
    {6,2,28},
    {6,2,10},
    {6,2,29},
    {6,2,40}
  },
  {
    {6,3,6},
    {6,3,30},
    {6,3,12},
    {6,3,25},
    {6,3,42}
  },
  {
    {6,4,20},
    {6,4,32},
    {6,4,14},
    {6,4,33},
    {6,4,38}
  },
  {
    {6,5,22},
    {6,5,34},
    {6,5,14},
    {6,5,33},
    {6,5,38}
  },
  {
    {6,6,24},
    {6,6,36},
    {6,6,18},
    {6,6,31},
    {6,6,42}
  }
};;
    
    public World(){
      
      //初始化變數
      spaces=new ArrayList <>();
      hbs_full=new ArrayList <>();
      hbs_half=new ArrayList <>();
      hbs_sixA=new ArrayList <>();
      hbs_sixB=new ArrayList <>();
      hbs_twL=new ArrayList <>();
      hbs_twR=new ArrayList <>();
//      blocksList = new ArrayList <ArrayList<? extends HoneyBlock>>();
      blocksList = new ArrayList <>();
      

      ifTheFirst=true;
      
      //將儲存方塊的
      blocksList.add(hbs_full);
      blocksList.add(hbs_half);
      blocksList.add(hbs_sixA);
      blocksList.add(hbs_sixB);
      blocksList.add(hbs_twL);
      blocksList.add(hbs_twR);
      
      
      
      PVector c=new PVector(0,0,0);
      Space s=new Space();
      s.setup();
      s.updateCenter(c);
     // s.pointsProjected[0].print();
      //s.updateSrf(1,1);
      spaces.add(s);
    }
    
    public void addSpace(int index,int connectSrf){      //原方塊的index、新方塊欲連接的面
      PVector next_center=new PVector(0,0,0);
      PVector recent_center=new PVector(this.spaces.get(index).center.x,this.spaces.get(index).center.y,this.spaces.get(index).center.z);
      PVector shift;
      
      //設定位移座標
      switch(connectSrf){
        case 22: case 23:
          shift=new PVector(-8.66f,5f,14.087f);
          break;  
        case 19: case 24:
          shift=new PVector(0,-10f,14.087f);
          break;  
        case 20: case 21:
          shift=new PVector(8.66f,5f,14.087f);
          break;  
        case 10: case 16:
          shift=new PVector(-8.66f,15f,0);
          break;  
        case 11: case 17:
          shift=new PVector(-17.32f,0,0);
          break;  
        case 12: case 18:
          shift=new PVector(-8.66f,-15f,0);
          break;  
        case 7: case 13:
          shift=new PVector(8.66f,-15f,0);
          break;  
        case 8: case 14:
          shift=new PVector(17.32f,0,0);
          break;  
        case 9: case 15:
          shift=new PVector(8.66f,5f,14.087f);
          break;  
        case 3: case 4:
          shift=new PVector(0,10f,-14.087f);
          break;  
        case 5: case 6:
          shift=new PVector(-8.66f,-5f,-14.087f);
           break;  
        case 1: case 2:
          shift=new PVector(8.66f,-5f,-14.087f);
          break;  
        default:
          shift=new PVector(0,0,0);
      }
      //新座標=原座標+位移
      next_center=recent_center.add(shift);
      //建立新空間
      Space s=new Space(); 
      s.setup();
      s.updateCenter(next_center);
      setSpaceLink(this.spaces.get(index),s,connectSrf,index); 
      spaces.add(s); 
    }
    
    //設置space之間的連結
    public void setSpaceLink(Space recent,Space next,int connectSrf,int index){    //原空間、新空間、新空間欲連接的面、原空間的編號
      next.srf_index[connectSrf-1]=index;
      recent.srf_index[recent.getsrf(connectSrf)-1]=this.spaces.size(); 
    }
  
    public void addBlock(String recent,int recent_type,String next,int next_type,int connectSrf,String method){
      
      boolean finish=false;
      int recentBlockType=0;    //舊方塊的類型
      int nextBlockType=0;      //新方塊的類型
      int count=0;              //計算舊方塊選擇失敗次數
      int recentIndex;          //被選擇舊方塊的index
      int nextIndex;            //新方塊加入的index
      int keySurface;           //新方塊位置的關鍵判斷面
      
      recentBlockType=getListIndex(recent);      //把舊方塊的類型轉成blocksList的index
      nextBlockType=getListIndex(next);          //把新方塊的類型轉乘blocksList的index
      
      recentIndex=chooseBase(method,recentBlockType,count);                 //選擇要使用陣列中哪一個作為舊方塊
      nextIndex=createBlock(nextBlockType);          //建立新方塊，並設定新方塊在陣列中的編號
      
      if(ifTheFirst){
        this.blocksList.get(nextBlockType).get(nextIndex).centerIndex=0;             //設定新方塊所屬的空間編號=跟舊方塊一樣
        spaces.get(0).updateSrf(nextBlockType,next_type);//設定新方塊加入後，面的使用狀況
        this.blocksList.get(nextBlockType).get(nextIndex).setup();  //新方塊setup
        this.blocksList.get(nextBlockType).get(nextIndex).computeNewPoints(next_type);//計算新方塊的頂點座標
        this.blocksList.get(nextBlockType).get(nextIndex).updateCenter(spaces.get(0).center);//先設定新方塊中心點
        ifTheFirst=false;
        return;
      }
      
      if((ifTheFirst==false)&&(blocksList.get(recentBlockType).size()==0)){
          this.blocksList.get(nextBlockType).remove(blocksList.get(nextBlockType).size()-1);
          return;
      }
      
      int recentSrf=this.spaces.get(0).getsrf(connectSrf);    //舊方塊相接面的編號
      int nextSrf=connectSrf;                                 //新方塊相接面的編號

      //len=this.blocksList.get(recentBlockType).size();    //取得舊方塊類型陣列的長度
      //this.blocksList.get(nextBlockType).get(nextIndex).computeNewPoints(next_type);//計算新方塊的頂點座標
      
      keySurface=blocksList.get(nextBlockType).get(recentIndex).getKeySurface(next_type);  //取得新方塊的關鍵判斷面
      while((count!=-1)&&(finish==false)){
        if(ifInside(connectSrf)){        //判斷新方塊是否會建立在舊方塊所屬的空間
          if(spaces.get(this.blocksList.get(recentBlockType).get(recentIndex).centerIndex).surfaces[recentSrf-1].z!=0){    //舊方塊：如果所屬空間欲連接的面沒有被使用完，就可以新增方塊
            this.blocksList.get(nextBlockType).get(nextIndex).centerIndex=recentIndex;             //設定新方塊所屬的空間編號=跟舊方塊一樣
            spaces.get(this.blocksList.get(recentBlockType).get(recentIndex).centerIndex).updateSrf(nextBlockType,next_type);//設定新方塊加入後，面的使用狀況
            this.blocksList.get(nextBlockType).get(nextIndex).setup();  //新方塊setup
            this.blocksList.get(nextBlockType).get(nextIndex).computeNewPoints(next_type);//計算新方塊的頂點座標
            this.blocksList.get(nextBlockType).get(nextIndex).updateCenter(spaces.get(this.blocksList.get(recentBlockType).get(recentIndex).centerIndex).center);//先設定新方塊中心點
            finish=true;
          }
          else{
              if(count<this.blocksList.get(recentBlockType).size()){
                count++;
                recentIndex=chooseBase(method,recentBlockType,count);
                //重新呼叫index計算函式，直到跑出可執行的編號
              }     
              count=-1;
          }
        }
        else{
          //如果舊方塊所屬的空間欲連接新方塊的面已經有下一個空間連接
          if(spaces.get(this.blocksList.get(recentBlockType).get(recentIndex).centerIndex).srf_index[recentSrf-1]!=-1){  
            //使用關鍵判斷面來判斷下一個空間欲連接位置是否有被佔用，如果尚有空間的話
            int nextSpaceIndex=spaces.get(this.blocksList.get(recentBlockType).get(recentIndex).centerIndex).srf_index[recentSrf-1];
            if(spaces.get(nextSpaceIndex).surfaces[keySurface-1].z!=0){
              this.blocksList.get(nextBlockType).get(nextIndex).centerIndex=nextSpaceIndex;  //設定新方塊所屬的空間編號
              spaces.get(nextSpaceIndex).updateSrf(nextBlockType,next_type);                 //設定新方塊加入後，面的使用狀況
              this.blocksList.get(nextBlockType).get(nextIndex).setup();
              this.blocksList.get(nextBlockType).get(nextIndex).computeNewPoints(next_type);
              this.blocksList.get(nextBlockType).get(nextIndex).updateCenter(spaces.get(nextSpaceIndex).center);  //新方塊的中心點是下一個空間的中心點
              finish=true;
            }
            else{
              if(count<this.blocksList.get(recentBlockType).size()){
                count++;
                recentIndex=chooseBase(method,recentBlockType,count);
                //重新呼叫index計算函式，直到跑出可執行的編號
              }     
              count=-1;
            }
          }
          else{
            this.addSpace(recentIndex,nextSrf);
            this.blocksList.get(nextBlockType).get(nextIndex).centerIndex=spaces.size()-1;//設定新方塊所屬的空間編號=空間陣列長度-1
            spaces.get(spaces.size()-1).updateSrf(nextBlockType,next_type);   //設定新方塊加入後，面的使用狀況
            this.blocksList.get(nextBlockType).get(nextIndex).setup();        //新方塊基本設定
            this.blocksList.get(nextBlockType).get(nextIndex).computeNewPoints(next_type);    //新方塊依照種類旋轉座標
            this.blocksList.get(nextBlockType).get(nextIndex).updateCenter(spaces.get(spaces.size()-1).center);    //新方塊加上中心點座標位移
            finish=true;
          }
        }
      }
      
      if(!finish){        //如果最後沒有順利建成，則刪除該新增方塊
        this.blocksList.get(nextBlockType).remove(blocksList.get(nextBlockType).size()-1);
      }
   }
      
    public int createBlock(int nextBlockType){
      if(nextBlockType==0){
        ((ArrayList) this.blocksList.get(nextBlockType)).add(new HB_full());
      }
      else if(nextBlockType==1){
        ((ArrayList) this.blocksList.get(nextBlockType)).add(new HB_half());
      }
      else if(nextBlockType==2){
        ((ArrayList) this.blocksList.get(nextBlockType)).add(new HB_onesixA());
      }
      else if(nextBlockType==3){
        ((ArrayList) this.blocksList.get(nextBlockType)).add(new HB_onesixB());
      }
      else if(nextBlockType==4){
        ((ArrayList) this.blocksList.get(nextBlockType)).add(new HB_onetwL());
      }
      else if(nextBlockType==5){
        ((ArrayList) this.blocksList.get(nextBlockType)).add(new HB_onetwR());
      }
      
      return this.blocksList.get(nextBlockType).size()-1;
    }
    
    public int getListIndex(String Type){
      switch(Type){
        case "full":
          return 0;
        case "half":
          return 1;
        case "sixA":
          return 2;
        case "sixB":
          return 3;
        case "twL":
          return 4;
        case "twR":
          return 5;
        default: return 0;
      }
    }
    
    //新方塊是否將建立在原Space內
    public boolean ifInside(int connectSrf){
      return (connectSrf>24)&&(connectSrf<43);
    }
    
    //選擇原方塊index
    public int chooseBase(String method,int recentBlockType,int count){
      int index=0;
      int[] sort;
      
      //第一個
      switch(method){
        case "first":
          return count;
        case "last":
          return blocksList.get(recentBlockType).size()-1-count;
        case "min":
          sort=sortMin(recentBlockType);
          if(count>sort.length)return 0;
          return sort[count];
        case "max":
          sort=sortMin(recentBlockType);
          if(count>sort.length)return 0;
          return sort[blocksList.get(recentBlockType).size()-1-count];
        case "random":
          return (int)Math.random()*blocksList.get(recentBlockType).size()-1;
        case "close":
          sort=sortClose(recentBlockType);
          return sort[count];      
      }
      //最後一個
      //剩餘最多連接面
      //剩餘最少連接面
      //隨機
      //離中心點最近
      return index;
    }
    
    public int[] sortMin(int recentBlockType){
      int[] a=new int[blocksList.get(recentBlockType).size()];
      int temp;
      int toIndex=blocksList.get(recentBlockType).size();
      
      for(int i=0;i<blocksList.get(recentBlockType).size();i++)a[i]=i;
      if(blocksList.get(recentBlockType).size()<2) return a;
      
      while(toIndex>1){
          toIndex--;
          for(int i=0;i<toIndex;i++){
              if(blocksList.get(recentBlockType).get(i).emptySrfNum()>blocksList.get(recentBlockType).get(i+1).emptySrfNum()){
                  temp=a[i];
                  a[i]=a[i+1];
                  a[i+1]=temp;
              }
          }
      }
//      for(int i=0;i<blocksList.get(recentBlockType).size();i++) a[i]=i;
//      for(int i=0;i<blocksList.get(recentBlockType).size();i++){
//        for(int j=0;j<blocksList.get(recentBlockType).size()-i;j++){
//          if(blocksList.get(recentBlockType).get(j).emptySrfNum()>blocksList.get(recentBlockType).get(j+1).emptySrfNum()){
//            temp=a[j];
//            a[j]=a[j+1];
//            a[j+1]=temp;
//          }
//        }
//      } 
      return a;
    }
    
    public int[] sortClose(int recentBlockType){
      int[] a={};
      int temp;
      PVector v,w;
      for(int i=0;i<blocksList.get(recentBlockType).size();i++) a[i]=i;
      for(int i=0;i<blocksList.get(recentBlockType).size();i++){
        for(int j=0;j<blocksList.get(recentBlockType).size()-i;j++){
          w=blocksList.get(recentBlockType).get(j).center;
          v=blocksList.get(recentBlockType).get(j+1).center;
          if(w.dist(0,0,0)>v.dist(0,0,0)){
            temp=a[j];
            a[j]=a[j+1];
            a[j+1]=temp;
          }
        }
      } 
      return a;
    }
    
    public float setScale(){
        float s=0;
        return s;
    }
    
    public int setType(int nextBlocksType,int connectSrf){
        ArrayList<Integer> type=new ArrayList<>();
               
        for(int[][] s:srf){
            if(s[0][0]==nextBlocksType+1){ 
                for(int[] s1:s){
                    if(s1[2]==connectSrf){
                        type.add(s1[1]);
                        break;
                    }
                }
            }
        }
        
        return type.get((int)Math.random()*type.size());
    }

//    public int setType(int listIndex, int connectS) {
//        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
//    }
    
}
