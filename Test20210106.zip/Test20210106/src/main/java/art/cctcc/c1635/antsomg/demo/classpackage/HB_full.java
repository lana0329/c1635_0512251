/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package art.cctcc.c1635.antsomg.demo.classpackage;

/**
 *
 * @author jenny
 */
public class HB_full extends HoneyBlock{
    public HB_full(){
    //super();
    this.pointsID = new int[14];
    edges = new PVector[24];
    for(int i=0;i<14;i++){
      pointsID[i]=i;
    }
    for(int i=1;i<4;i++)connect(0,i,i-1);
    for(int i=1;i<7;i++)connect(i,i+6,i+2);
    for(int i=0;i<2;i++){
      connect(1+i*6,4+i*6,6*i+9);
      connect(4+i*6,2+i*6,6*i+10);
      connect(2+i*6,5+i*6,6*i+11);
      connect(5+i*6,3+i*6,6*i+12);
      connect(3+i*6,6+i*6,6*i+13);
      connect(6+i*6,1+i*6,6*i+14);
    }
    for(int i=10;i<13;i++)connect(13,i,i+11);
  }
  @Override
  public int getKeySurface(int next_type){
    return 1;
  }
}
