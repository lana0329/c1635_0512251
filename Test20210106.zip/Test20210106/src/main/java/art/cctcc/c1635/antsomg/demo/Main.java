/*
 * Copyright 2019 Jonathan Chang, Chun-yien <ccy@musicapoetica.org>.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package art.cctcc.c1635.antsomg.demo;

import java.awt.Color;
import java.util.Map;
import static java.util.function.Predicate.not;
import java.util.stream.Collectors;
import processing.core.PApplet;
import tech.metacontext.ocnhfa.antsomg.impl.StandardGraph;
//import art.cctcc.c1635.antsomg.demo.classpackage.HoneyBlock;
import art.cctcc.c1635.antsomg.demo.classpackage.World;
import art.cctcc.c1635.antsomg.demo.classpackage.PVector;
import java.util.ArrayList;
import java.util.Arrays;

/**
 *
 * @author Jonathan Chang, Chun-yien <ccy@musicapoetica.org>
 */
public class Main extends PApplet {

    int size = 1200;
    SpiralSystem demo;
    //float theta;
    //Map<SpiralAnt, Float> radius;
    World world = new World();

    @Override
    public void settings() {
        size(size, size);
    }

    @Override
    public void setup() {
//        colorMode(RGB);
//        background(0);
//        noFill();
        demo = new SpiralSystem(1);
        demo.init_graphs();
        demo.init_population();
        //radius = demo.ants.stream()
         //       .collect(Collectors.toMap(ant -> ant, ant -> 10f));
    }
    float move_amount = 2.5f;
    float delta_theta = 1f;

    float scale=15f;
    float angle=0f;
    
    ArrayList <String> methodSet=new ArrayList<>();
    String[] method={"FIRST","LAST","MIN","MAX","RANDOM"};
    
    @Override
    public void draw() {
        background(0);
            demo.ants.stream()
                    .filter(not(SpiralAnt::isCompleted))
                    .forEach(ant -> {
                        var move = ant.getCurrentTrace().getDimension("x");
                        methodSet.add(ant.getCurrentTrace().getDimension("y").getName());
                        if(move.getName().charAt(0)=='N'){
                           ant.connectS=Integer.valueOf(move.getName().substring(1));
                           ant.nextType=world.setType(world.getListIndex(ant.next),ant.connectS);
                           if(ant.route.size()>1){
                               //world.addBlock(ant.recent,ant.recentType,ant.next,ant.nextType,ant.connectS,method);
                               System.out.printf("%s,%d,%s,%d,%d\n",ant.recent,ant.recentType,ant.next,ant.nextType,ant.connectS);
                            }
                           ant.setRecent();
                        }
                        else{
                            ant.next=move.getName();
                        }
                   });
            
            //this.theta += delta_theta * PI / 180;
            if (demo.isAimAchieved()) {
                System.out.println(method[count(methodSet,method.length)]);
                
                //computeMethod
                //String[] method={"FIRST","LAST","MIN","MAX","RANDOM"};
                
//                demo.getGraphs().values().stream()
//                        .map(StandardGraph::asGraphviz)
//                        .forEach(System.out::println);
                noLoop();
            } else {
                demo.navigate(); 
            }
            
    }

    public static int count(ArrayList <String> array,int maxValue){
        int[] count = new int[maxValue]; 
        for (String n : array) {
            int i=-1;
            switch(n){
                case "FIRST":
                    i=0;
                    break;
                case "LAST":
                    i=1;
                    break;
                case "MIN":
                    i=2;
                    break;
                case "MAX":
                    i=3;
                    break;
                case "RANDOM":
                    i=4;
                    break;  
            }
            if(i>0)count[i]++;
        } // increment the counter for that value. 
        
        int[] temp=new int[maxValue];
        for(int i=0;i<maxValue;i++)temp[i]=count[i];
        Arrays.sort(temp);
        int result=0;
        for(int j=0;j<maxValue;j++){
            if(count[j]==temp[maxValue-1]) result=j;
        }
        return result; 
    }
    
    public static void main(String[] args) {
        System.setProperty("sun.java2d.uiScale", "1.0");
        PApplet.main(Main.class);
    }
    
    
}
