/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package art.cctcc.c1635.antsomg.demo.classpackage;

/**
 *
 * @author jenny
 */
public class Space extends HoneyBlock{
    int[] srf_index;
  
  public Space(){
    
    srf_index =new int[24];
    for(int i=0;i<24;i++){
      srf_index[i]=-1;
    }
    
    //super();
    this.pointsID = new int[14];
    edges = new PVector[24];
    for(int i=0;i<14;i++){
      pointsID[i]=i;
    }
    for(int i=1;i<4;i++)connect(0,i,i-1);
    for(int i=1;i<7;i++)connect(i,i+6,i+2);
    for(int i=0;i<2;i++){
      connect(1+i*6,4+i*6,6*i+9);
      connect(4+i*6,2+i*6,6*i+10);
      connect(2+i*6,5+i*6,6*i+11);
      connect(5+i*6,3+i*6,6*i+12);
      connect(3+i*6,6+i*6,6*i+13);
      connect(6+i*6,1+i*6,6*i+14);
    }
    for(int i=10;i<13;i++)connect(13,i,i+11); 
  }
  
  public void updateSrf(int nextBlockType,int next_tpye){
      int[][][] srf={
        {
          {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24}
        },
        {
          {1,2,3,4,5,6,7,8,9,10,11,12,37,38,39,40,41,42},
          {13,14,15,16,17,18,19,20,21,22,23,24,37,38,39,40,41,42}
        },
        {
          {1,2,7,8,25,27,37,38},
          {3,4,9,10,27,29,39,40},
          {5,6,11,12,25,29,41,42},
          {13,18,19,24,32,36,37,42},
          {14,15,20,21,32,34,38,39},
          {16,17,22,23,34,36,40,41}
        },
        {
          {1,6,7,12,26,30,37,42},
          {2,3,8,9,26,28,38,39},
          {4,5,10,11,28,30,40,41},
          {13,14,19,20,31,33,37,38},
          {15,16,21,22,33,35,39,40},
          {17,18,23,24,31,35,41,42}
        },
        {
          {1,7,25,26,37},
          {3,9,27,28,39},
          {5,11,29,30,41},
          {13,19,31,32,37},
          {15,21,33,34,39},
          {17,23,35,36,41},
        },
        {
          {2,8,26,27,38},
          {4,10,28,29,40},
          {6,12,25,30,42},
          {14,20,32,33,38},
          {16,22,34,35,40},
          {18,24,31,36,42}
        }
      };
      
      int max=srf[nextBlockType][next_tpye-1].length;
      int index=0;
      
      for(int i=0;i<max;i++){
        for(PVector s:surfaces){
        if(srf[nextBlockType][next_tpye-1][i]==s.x)s.z-=1;
        }
      }
      
  }
  
//  @Override
//  public void draw(){
//    strokeWeight(1);
//    stroke(100);
//    noFill();
//    
//    for(PVector e : this.edges){
//      int a = int(e.x);
//      int b = int(e.y);
//      PVector va = this.pointsProjected[a];
//      PVector vb = this.pointsProjected[b];
//      line(va.x,va.y,vb.x,vb.y);
//    }
//  }
    
}
