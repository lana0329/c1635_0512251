/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package art.cctcc.c1635.antsomg.demo.classpackage;

/**
 *
 * @author jenny
 */
public class HoneyBlock {
  PVector[] points;
  PVector[] edges;
  int[] pointsID;
  PVector[] pointsProjected;
  PVector[] temp_points;
  PVector[] surfaces;
  PVector center;
  int centerIndex;
  
  public void setup(){
    points = new PVector[21];
    pointsProjected = new PVector[21];
    temp_points = new PVector[21];
    surfaces = new PVector[42];
    center=new PVector(0,0,0);
    
    //設定頂點座標
    this.points[0] = new PVector(0,0,10.538f);
    this.points[1] = new PVector(0,10,7.044f);
    this.points[2] = new PVector(-8.66f,-5f,7.044f);
    this.points[3] = new PVector(8.66f,-5f,7.044f);
    this.points[4] = new PVector(-8.66f,5f,3.549f);
    this.points[5] = new PVector(0,-10f,3.549f);
    this.points[6] = new PVector(8.66f,5f,3.549f);
    this.points[7] = new PVector(0,10,-3.549f);
    this.points[8] = new PVector(-8.66f,-5f,-3.549f);
    this.points[9] = new PVector(8.66f,-5f,-3.549f);
    this.points[10] = new PVector(-8.66f,5f,-7.044f);
    this.points[11] = new PVector(0,-10f,-7.044f);
    this.points[12] = new PVector(8.66f,5f,-7.044f);
    this.points[13] = new PVector(0,0,-10.538f);
    this.points[14] = new PVector(0,10f,0);
    this.points[15] = new PVector(-8.66f,5f,0);
    this.points[16] = new PVector(-8.66f,-5f,0);
    this.points[17] = new PVector(0,-10f,0);
    this.points[18] = new PVector(8.66f,-5f,0);
    this.points[19] = new PVector(8.66f,5f,0);
    this.points[20] = new PVector(0,0,0);
    
    //設定對應面以及使用次數
    this.surfaces[0]=new PVector(1,23,1);
    this.surfaces[1]=new PVector(2,22,1);
    this.surfaces[2]=new PVector(3,19,1);
    this.surfaces[3]=new PVector(4,24,1);
    this.surfaces[4]=new PVector(5,21,1);
    this.surfaces[5]=new PVector(6,20,1);
    for(int i=6;i<9;i++) this.surfaces[i]=new PVector(i+1,i+4,1);
    for(int i=9;i<12;i++) this.surfaces[i]=new PVector(i+1,i-2,1);
    for(int i=12;i<15;i++) this.surfaces[i]=new PVector(i+1,i+4,1);
    for(int i=15;i<18;i++) this.surfaces[i]=new PVector(i+1,i-2,1);
    this.surfaces[18]=new PVector(19,3,1);
    this.surfaces[19]=new PVector(20,6,1);
    this.surfaces[20]=new PVector(21,5,1);
    this.surfaces[21]=new PVector(22,2,1);
    this.surfaces[22]=new PVector(23,1,1);
    this.surfaces[23]=new PVector(24,4,1);
    for(int i=24;i<42;i++)this.surfaces[i]=new PVector(i+1,i+1,2); 
   
    
    //儲存子物件的頂點座標到temp_points
    for(int i=0;i<21;i++) {
      for(int id : this.pointsID){
        if(i==id)this.temp_points[i] = this.points[id];
      }
    
    }
  }
  
  public void updateCenter(PVector c){
    this.center=c;
    //頂點平移
    for(int i=0;i<21;i++){
      if(this.temp_points[i]!=null) this.temp_points[i]=this.temp_points[i].add(this.center);
    }
    
  }
 
  //回傳對應面
  public int getsrf(int index){
    return (int)this.surfaces[index-1].y;
  }
  
  //回傳空間判斷用關鍵代表面
  public int getKeySurface(int next_type){return 1;};
  
  //邊的連接
  public void connect(int i,int j,int index){
    this.edges[index] = new PVector(i,j);
  }
  
  //計算2D繪圖投影座標
  public void compuProj(float angle,float scale){
    //rotate matrix
    float[][] rotateX={
    {1,0,0},
    {0,(float)Math.cos(angle),-(float)Math.sin(angle)},
    {0,(float)Math.sin(angle),(float)Math.cos(angle)}
    };
    float[][] rotateY={
      {(float)Math.cos(angle),0,-(float)Math.sin(angle)},
      {0,1,0},
      {(float)Math.sin(angle),0,(float)Math.cos(angle)}
    };
    float[][] rotateZ={
      {(float)Math.cos(angle),-(float)Math.sin(angle),0},
      {(float)Math.sin(angle),(float)Math.cos(angle),0},
      {0,0,1}
    };
    
    //rotate
    for(int i=0;i<21;i++){
      //PVector v = new PVector();
      //if(this.temp_points[i]!=null)v.setValue(this.temp_points[i]);

      if(this.temp_points[i]!=null){
        PVector rotated2d=new PVector();
        rotated2d.matmul(rotateX,this.temp_points[i]);
        rotated2d.matmul(rotateY,rotated2d);
        rotated2d.matmul(rotateZ,rotated2d);
        //set z-distance 
        float distance=1.1f;
        float z=1/(distance-rotated2d.z/50);
        //float z=1;
        float[][] projection={
          {z,0,0},
          {0,z,0},
          {0,0,0}
        };
        PVector projected2d = new PVector();
        projected2d.matmul(projection,rotated2d);
        projected2d.mult(scale);
        this.pointsProjected[i]=projected2d;
      }
    }
  }
  
  //繪製
  public void draw(){
//    strokeWeight(3);
//    stroke(255);
//    noFill();
//    for(PVector e : this.edges){
//      int a = int(e.x);
//      int b = int(e.y);
//      PVector va = this.pointsProjected[a];
//      PVector vb = this.pointsProjected[b];
//      line(va.x,va.y,vb.x,vb.y);
    //}
    
  }
 
  public void computeNewPoints(int next_type){
    float angleY=0;
    float angleZ=0;
    
    switch(next_type){
      case 2:
        angleZ=(float)Math.PI*120/180;
        break;
      case 3: 
        angleZ=(float)Math.PI*240/180;
        break;
      case 4:
        angleY=(float)Math.PI;
        angleZ+=(float)Math.PI*60/180;
        break;
      case 5:
        angleZ=(float)Math.PI*120/180;
        angleY=(float)Math.PI;
        angleZ+=(float)Math.PI*60/180;
        break;
      case 6:
        angleZ=(float)Math.PI*240/180;
        angleY=(float)Math.PI;
        angleZ+=(float)Math.PI*60/180;
        break;
    }
   
    if(next_type==1){
      angleY=0;
      angleZ=0;
    }

    //float[][] rotateX={
    //{1,0,0},
    //{0,cos(angleX),-sin(angleX)},
    //{0,sin(angleX),cos(angleX)}
    //};
    
    float[][] rotateY={
      {(float)Math.cos(angleY),0,-(float)Math.sin(angleY)},
      {0,1,0},
      {(float)Math.sin(angleY),0,(float)Math.cos(angleY)}
    };
    float[][] rotateZ={
      {(float)Math.cos(angleZ),-(float)Math.sin(angleZ),0},
      {(float)Math.sin(angleZ),(float)Math.cos(angleZ),0},
      {0,0,1}
    };
    
    int index=0;
    for(PVector v: temp_points){
      if(v!=null){
        v.matmul(rotateY,v);
        v.matmul(rotateZ,v);
        temp_points[index]=v;
      }
      else{
        temp_points[index]=null;
      }
      index++;
    }
    
  }
  
  public int emptySrfNum(){
    int sum=0;
    for(int i=0;i<42;i++){
      if(surfaces[i].z!=0){
        sum+=surfaces[i].z;
      }
    }
    return sum;
  }
  
  public PVector[] getPointsProjected(){
      return pointsProjected;
  }
  
  public PVector[] getEdges(){
      return edges;
  }
}
