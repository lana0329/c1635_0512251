/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package art.cctcc.c1635.antsomg.demo.classpackage;

/**
 *
 * @author jenny
 */
public class HB_onesixA extends HoneyBlock{
    public HB_onesixA(){
    //super();
    this.pointsID = new int[8];
    edges = new PVector[12];
    pointsID[0]=0;
    pointsID[1]=1;
    pointsID[2]=4;
    pointsID[3]=2;
    pointsID[4]=14;
    pointsID[5]=15;
    pointsID[6]=16;
    pointsID[7]=20;
    connect(0,1,0);
    connect(1,4,1);
    connect(4,2,2);
    connect(2,0,3);
    connect(1,14,4);
    connect(4,15,5);
    connect(2,16,6);
    connect(0,20,7);
    connect(14,15,8);
    connect(15,16,9);
    connect(16,20,10);
    connect(20,14,11);
  }
  
  @Override
  public int getKeySurface(int next_type){
    switch(next_type){
      case 1:
        return 1;
      case 2:
        return 3;
      case 3:
        return 5;
      case 4:
        return 19;
      case 5:
        return 20;
      case 6:
        return 22;
      default:
        return 0;
    }
  }
}
