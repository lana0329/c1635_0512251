/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package art.cctcc.c1635.antsomg.demo.classpackage;

/**
 *
 * @author jenny
 */
public class PVector {
    float x;
    float y;
    float z;
    
    public PVector(){}
    public PVector(float _x,float _y){
        this.x=_x;
        this.y=_y;
        this.z=0;
    }
    public PVector(float _x,float _y,float _z){
        this.x=_x;
        this.y=_y;
        this.z=_z;
    }
    
    public PVector(PVector v){
        this.x=v.x;
        this.y=v.y;
        this.z=v.z;
    }
   
    public PVector add(PVector v){
        PVector n;
        n=new PVector(this.x+v.x,this.y+v.y,this.z+v.z);
        return n;
    }
    
    public void setValue(PVector v){
        this.x=v.x;
        this.y=v.y;
        this.z=v.z;
    }
    
    public void print(){
        System.out.printf("(%f,%f,%f)\n",this.x,this.y,this.z);
    }
    
    public void mult(float scale){
        this.x*=scale;
        this.y*=scale;
        this.z*=scale;
    }
    
    public static float[][] vecToMat(PVector v){
        float[][] m =new float[3][1];
        m[0][0]=v.x;
        m[1][0]=v.y;
        m[2][0]=v.z;
        return m;
   }

    public static PVector matToVec(float[][] m){
        PVector v=new PVector();
        v.x=m[0][0];
        v.y=m[1][0];
        if(m.length>2){
          v.z=m[2][0];
        }
        return v;
    }
    
    public void matmul(float[][] a,PVector v){
        float[][] b=vecToMat(v);
        int colsA = a[0].length;
        int rowsA = a.length;
        int colsB = b[0].length;
        int rowsB = b.length;

        if(colsA != rowsB){
          System.out.println("Columns of A must match rows of B");
        }

        float result[][]= new float[rowsA][colsB];

        for(int i=0;i<rowsA;i++){
          for(int j=0;j<colsB;j++){
            float sum=0;
            for(int k=0;k<colsA;k++){
              sum+=a[i][k]*b[k][j];
            }
            result[i][j]=sum;
          }
        }
        this.setValue(matToVec(result));
    }
    
    public  float dist(float ux,float uy,float uz){
        double d;
        d=Math.pow((Math.pow(ux-this.x,2)+Math.pow(uy-this.y,2)+Math.pow(uz-this.z,2)), 0.5);
        return (float)d;
    }
    
    public float getX(){
     return this.x;
    }
    
    public float getY(){
        return this.y;
    }
    
    public float getZ(){
        return this.z;
    }
}
